create function pga_is_leap_year(smallint) returns boolean
    immutable
    language plpgsql
as
$$
BEGIN
    IF $1 % 4 != 0 THEN
        RETURN FALSE;
    END IF;

    IF $1 % 100 != 0 THEN
        RETURN TRUE;
    END IF;

    RETURN $1 % 400 = 0;
END;
$$;

comment on function pga_is_leap_year(smallint) is 'Returns TRUE if $1 is a leap year';

alter function pga_is_leap_year(smallint) owner to postgres;

